
        console.log(rows.affectedRows);